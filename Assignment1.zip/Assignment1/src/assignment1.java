//Assignment one, SYSC2100, Gabriele Sarwar, 101010867

import java.io.*;

public class assignment1 {

	public static void main(String[] args) {
	
		File myfile = new File("C:\\Users\\User\\Desktop\\Math-3705"); //a file in my comp
			
		//long c=diskUsage(myfile); // call the diskusage method
		
		//System.out.println(c); // print the total size 
		find(myfile,"HUB.txt"); //call the find method
		//solveTowers(4, "left", "middle","right"); //call the solvetowers method
		
	}
	
	//QUESTION 1 PART 1 Of ASSIGNMENT 1
	// a recursive Java program to find the total disk usage (in bytes) of the portion 
	//of a file system.
	//@Param the file he or she chooses
	///@return the total size of root file
	
	public static long diskUsage(File root) {
		long TotalSize = 0; //stores the size in bytes
		if (root.exists() == false) { //if its not a valid root exit
			return -1;
		}
		int size = root.listFiles().length; //total size of root
		File[] filelist = new File[size]; //array of files
		filelist = root.listFiles();//a list of files in the root
		
		for(int i=0; i<size; i++) {
			if(filelist[i].isFile()){ // if its a file add to total size
				TotalSize = TotalSize + filelist[i].length();
				}
			else {	//if its not a file recall function on the folders		
				TotalSize = TotalSize + diskUsage(filelist[i]);
				}
		}
		return TotalSize;
	} 

	//QUESTION 2 PART 1 Of Assignment 1
	// a recursive Java program that reports all entries of the file system rooted at the given path having the given
	//file name.
	//@Param the path of root folder and the file name to be found
	
	public static void find(File root, String name) {
		//beginning of code is same as first function for part 1
		if (root.exists() == false) {
			System.out.println("not a file");
		}
		if (root.exists() == true) {
		int size = root.listFiles().length;
		File[] filelist = new File[size];
		filelist = root.listFiles();
		for(int i=0; i<size; i++) {
			if(filelist[i].isFile()){				
				if(filelist[i].getName().equals(name)) {//if the file has same name as given name
				System.out.println("the path of " + name + " is in " + filelist[i].toString()); //output only that file
				}
			}
			else {			
				find(filelist[i],name); // if its not a file we recall function at that folder
			}
		}
	  }
   }
	
	//QUESTION 3 for assignment 1, program that solves tower of hoani
	//@param nummberof disks he or she chooses, the A source post character, A destination post character, and A character to use for the other post.
	
	public static void solveTowers(int numberofdiscs, String start, String spare, String end) {
	       if (numberofdiscs == 1) {
	           System.out.println("move disk" + numberofdiscs + " from "+ start + " to " + end);
	       }
	       else if(numberofdiscs<1){
	    	   System.out.print("u need at least one disk");
	    	   return;   
	       } 
	       else {
	    	   solveTowers(numberofdiscs - 1, start, end, spare);
	           System.out.println("move disk" + numberofdiscs + " from " + start + " to " + end);
	           solveTowers(numberofdiscs - 1, spare, start, end);
	       }
	   }
}
 
		
 
	
	


